package com.mystrey.magicaccount.entity;

public class AboutAccount {
    private Integer id;
    private String tName;
    private String isOut;
    private String ICON;
}
