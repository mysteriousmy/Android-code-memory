package com.mystrey.magicaccount.entity;

public class Resources {

    public static final String TIME_PATTERN = "yyyy–MM–dd";
    public static final String DB_NAME = "account";
    public static final int DB_VERSION = 2;

}
